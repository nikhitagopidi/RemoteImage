package com.example.nikhita.remoteimage;

import android.graphics.Bitmap;
import android.os.AsyncTask;

/**
 * Created by Nikhita on 10/22/2014.
 */
public class ImageAsyncTask extends AsyncTask<String,Integer,Bitmap>{
    @Override
    protected Bitmap doInBackground(String... urls) { return null; }

    @Override
    protected void onPostExecute(Bitmap img) { super.onPostExecute(img); }

    @Override
    protected void onPreExecute() { super.onPreExecute(); }

    @Override
    protected void onProgressUpdate(Integer... values) { super.onProgressUpdate(values); }
}
